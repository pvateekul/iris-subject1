# food defects > 2025-11-18 7:49pm
https://universe.roboflow.com/fooddefects/food-defects-ouetf

Provided by a Roboflow user
License: CC BY 4.0

