# RCA Categories

Use these categories to structure RCA hypotheses.

## People

Training, handover, staffing, supervision, or role clarity.

## Process

Work instruction, process control, sequence, changeover, standard checks, escalation flow.

## Equipment

Machine condition, calibration, capacity, alarms, sensors, breakdowns, maintenance.

## Material

Ingredient variation, packaging material, supplier lot, storage condition, incoming quality.

## Measurement

Probe placement, record accuracy, calibration, sampling frequency, inspection method.

## Environment

Room temperature, humidity, airflow, sanitation condition, work area layout.

## Supplier

Supplier process change, late delivery, inconsistent raw material, documentation issue.

## Documentation / Recordkeeping

Missing logs, incomplete action records, unclear owner, outdated SOP, unclear acceptance criteria.
