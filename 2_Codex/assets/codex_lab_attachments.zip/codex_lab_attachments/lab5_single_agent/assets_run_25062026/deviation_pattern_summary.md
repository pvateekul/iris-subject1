# Deviation Pattern Summary

## Data Used
- Source file: `data/food_deviation_log.csv`
- Date range: 2026-05-01 to 2026-05-12
- Number of records: 12
- Key fields available: date, product, line, shift, process_step, deviation_type, severity, description, action_taken, owner, status
- Key fields missing: due date, batch ID, quantity affected, measured values, acceptance limits, release decision, verification evidence, recurrence closure notes

## Key Patterns
| Pattern | Evidence | Affected Area | Severity | Priority |
|---|---|---|---|---|
| Repeated cooling delays and one incomplete cooling record | 4 cooling-related records on Chilled chicken meal, Line 1; 3 are High severity cooling delays and 1 is Medium severity incomplete cooling record | Cooling, Line 1, Morning and Night shifts | High / Medium | High |
| Repeated metal detector rejects | 3 records for Vegetable curry on Line 3; all Medium severity; 2 remain Open | Metal detection, Line 3, Morning and Night shifts | Medium | Medium |
| Label and allergen control issues | 2 Tomato sauce label mix-ups on Line 2 and 2 Beef rice bowl missing allergen checks on Line 1 | Packing / Labeling, Lines 1 and 2, Afternoon mainly | High / Medium | High |
| Open actions concentrated in QA, maintenance, and packing follow-up | 8 of 12 records are Open; QA Supervisor owns 5 records, Maintenance owns 3, Packing Lead owns 3 | Cross-functional action management | High / Medium | High |

## Repeated Issues
- Issue: Cooling delay / cooling record weakness
  - Where it appears: Chilled chicken meal, Line 1, Cooling step, Morning and Night shifts
  - How often: 4 of 12 records
  - Why it matters: Cooling performance is important for chilled products, and the log does not include measured temperatures, target limits, batch size, or final release decision.

- Issue: Label mix-up and missing allergen verification
  - Where it appears: Tomato sauce on Line 2 Packing; Beef rice bowl on Line 1 Labeling
  - How often: 4 of 12 records
  - Why it matters: Label accuracy affects legal compliance, shelf-life control, and allergen risk. Two allergen verification misses are High severity.

- Issue: Metal detector reject recurrence
  - Where it appears: Vegetable curry, Line 3, Metal detection, Morning and Night shifts
  - How often: 3 of 12 records
  - Why it matters: Repeated rejects may indicate equipment setting, product effect, reject mechanism, or foreign material control issues, but the log does not confirm the cause.

## Priority Areas for Review
1. Confirm containment, temperature evidence, and release status for Chilled chicken meal cooling deviations.
2. Confirm label reconciliation, line clearance, and allergen verification evidence for label-related deviations.
3. Review metal detector challenge tests, sensitivity settings, reject mechanism checks, and maintenance records for Vegetable curry on Line 3.
4. Close or assign due dates to open QA, maintenance, and packing actions.

## Data Gaps
- Missing information: batch IDs, quantities affected, measured values, target limits, due dates, final disposition, verification evidence, and recurrence checks.
- Why it matters: These gaps prevent confirmation of true root cause, final risk status, and action effectiveness.
