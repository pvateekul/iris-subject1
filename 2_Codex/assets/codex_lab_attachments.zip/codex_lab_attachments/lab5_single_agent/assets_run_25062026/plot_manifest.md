# Plot Manifest

## Created Plots
| Plot | File | Data Used | What It Shows | Notes |
|---|---|---|---|---|
| Deviations by Process Step | `assets/plots/deviations_by_process_step.png` | `process_step` from `data/food_deviation_log.csv` | Cooling has the highest count, followed by Packing and Metal detection. | Supported by available categorical data. |
| Deviations by Deviation Type | `assets/plots/deviations_by_deviation_type.png` | `deviation_type` from `data/food_deviation_log.csv` | Cooling delay and metal detector reject are the most repeated deviation types. | Counts are small and should be used as screening evidence. |
| Open Deviations by Owner | `assets/plots/open_deviations_by_owner.png` | `owner` and `status` from `data/food_deviation_log.csv` | Open follow-up is concentrated with QA Supervisor, Maintenance, Production Supervisor, and Packing Lead. | The log does not include due dates or closure evidence. |
| Deviations by Severity and Status | `assets/plots/deviations_by_severity_status.png` | `severity` and `status` from `data/food_deviation_log.csv` | Open deviations include High and Medium severity records. | Severity definitions are not included in the provided references. |

## Skipped or Unsupported Plots
| Requested Plot | Reason Skipped |
|---|---|
| None | All requested plots were supported by available fields. |
