---
name: food-deviation-log-analyzer
description: Analyzes food production deviation logs to identify repeated issues, affected process steps, risk patterns, and priority areas for QA follow-up.
---

# Food Deviation Log Analyzer

This skill helps analyze food production deviation logs and turn raw records into a concise pattern summary.

## When to Use This Skill

Use this skill when the task involves:

- Reviewing food deviation logs
- Finding repeated quality or process issues
- Grouping issues by line, shift, product, process step, or risk type
- Identifying patterns that need QA or production follow-up
- Preparing input for RCA or corrective action planning

## Typical Inputs

Read from project references or data files such as:

- `data/food_deviation_log.csv`
- `references/process_notes.md`
- `references/qa_guidelines.md`
- `references/risk_category_guide.md`

Expected useful columns may include:

- date
- product
- line
- shift
- process_step
- deviation_type
- severity
- description
- action_taken
- owner
- status

If columns are missing, state the gap instead of guessing.

## Workflow

1. Inspect the available deviation log.
2. Identify the main fields and any missing fields.
3. Group deviations by useful dimensions:
   - product
   - production line
   - shift
   - process step
   - deviation type
   - severity
4. Identify repeated issue patterns.
5. Highlight high-risk or high-frequency areas.
6. Separate evidence from assumptions.
7. Prepare a concise pattern summary for downstream RCA.

## Output Requirements

Create a structured summary with:

```md
# Deviation Pattern Summary

## Data Used
- Source file:
- Date range:
- Number of records:
- Key fields available:
- Key fields missing:

## Key Patterns
| Pattern | Evidence | Affected Area | Severity | Priority |
|---|---|---|---|---|

## Repeated Issues
- Issue:
  - Where it appears:
  - How often:
  - Why it matters:

## Priority Areas for Review
1.
2.
3.

## Data Gaps
- Missing information:
- Why it matters:
```

## Guardrails

- Do not claim a true root cause.
- Do not invent missing data.
- Do not overstate weak patterns.
- Clearly label assumptions.
- Use only provided project files and references.
