---
name: follow-up-question-generator
description: Generates prioritized follow-up questions for QA, production, maintenance, or suppliers based on food process issue patterns and RCA hypotheses.
---

# Follow-up Question Generator

This skill creates practical follow-up questions that help QA and production teams investigate food process issues.

## When to Use This Skill

Use this skill when the task involves:

- Preparing questions for QA investigation
- Clarifying missing information
- Turning RCA hypotheses into investigation steps
- Asking production, maintenance, supplier, or QA teams for evidence
- Prioritizing what to ask first

## Typical Inputs

This skill may use:

- `assets/deviation_pattern_summary.md`
- `assets/rca_hypothesis_table.md`
- `data/food_deviation_log.csv`
- `references/process_notes.md`
- `references/qa_guidelines.md`

## Workflow

1. Read the issue pattern and RCA hypotheses.
2. Identify missing information.
3. Convert missing information into clear questions.
4. Group questions by owner:
   - QA
   - Production
   - Maintenance
   - Warehouse
   - Supplier
   - Management
5. Prioritize questions:
   - Priority 1: needed to confirm safety or containment
   - Priority 2: needed to confirm root cause
   - Priority 3: useful for prevention or documentation
6. Keep questions short and answerable.

## Output Requirements

```md
# Follow-up Questions

## Priority Questions

| Priority | Question | Owner | Why It Matters | Evidence Needed |
|---|---|---|---|---|

## Questions by Team

### QA
-

### Production
-

### Maintenance
-

### Supplier / Warehouse
-

## Notes

- These questions are intended to support investigation.
- They should be answered before confirming root cause or final corrective actions.
```

## Guardrails

- Do not ask vague questions.
- Do not ask too many questions.
- Prioritize the most important 5–10 questions.
- Avoid blame-oriented wording.
- Focus on evidence, timing, process conditions, records, and ownership.
